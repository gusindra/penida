<?php return array (
  'setting-home-page' => 'App\\Http\\Livewire\\SettingHomePage',
  'setting-social-media' => 'App\\Http\\Livewire\\SettingSocialMedia',
  'settings' => 'App\\Http\\Livewire\\Settings',
);