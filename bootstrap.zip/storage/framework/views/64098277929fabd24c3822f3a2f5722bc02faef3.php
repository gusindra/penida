<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-sm-5">
                <div class="text-left">
                    <ul>
                        <?php $__currentLoopData = $sosmed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e($s->konten); ?>"><i class="fa fa-<?php echo e($s->judul); ?>" aria-haspopup="true"></i></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-xs-12 col-sm-7">
                <div class="text-right">
                    <p>&copy; Copyright <?php echo e(date('Y')); ?>. All Rights Reserved.</p>
                </div>
            </div>
        </div>
    </div>
</footer>

<!-- Bact to top Section-->
<div class="back-top">
    <a href="#"><i class="fa fa-angle-up"></i></a>
</div><?php /**PATH C:\laragon\www\penida\resources\views/layouts/travel/footer.blade.php ENDPATH**/ ?>