<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php echo $__env->make('layouts.travel.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body id="page-top">
	<!--Preload-->
	<div class="preloader">
		<div class="preloader_image"></div>
	</div>

    <?php echo $__env->make('layouts.travel.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <!-- ****** Footer Area Start ****** -->
    <?php echo $__env->make('layouts.travel.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ****** Footer Area End ****** -->

    <?php echo $__env->make('layouts.travel.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\penida\resources\views/layouts/travel/main.blade.php ENDPATH**/ ?>