<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Edit Pages')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <!--main-container-part-->
                <div id="content">

                    <!--End-breadcrumbs-->
                    <div class="container-fluid">
                        <!--Action boxes-->
                        <div class="row-fluid">
                            <div class="widget-box">
                                <div class="widget-title"> <span class="icon"> <i class="icon-book"></i> </span>
                                    <h5>Halaman edit</h5>
                                </div>
                                <?php if(session('message')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('message')); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                                <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="widget-content">
                                    <div class="control-group">
                                        <form method="POST" enctype="multipart/form-data" action="<?php echo e(route('update.karang', $hal->id)); ?>"  >
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="_method" value="PUT">
                                            <div class="control-group">
                                                <div class="controls span6">
                                                    <div class="controls">
                                                        <label>Tipe</label>
                                                        <select name="tipe">
                                                            <option <?php echo e($hal->tipe=='page'?'selected':''); ?> value="page">Page</option>
                                                            <option <?php echo e($hal->tipe=='tour'?'selected':''); ?> value="tour">Package & Tour</option>
                                                            <option <?php echo e($hal->tipe=='hotel'?'selected':''); ?> value="hotel">Hotel</option>
                                                        </select>
                                                    </div>
                                                    <br>
                                                    <div class="controls">
                                                        <label>No Urut</label>
                                                        <input value="<?php echo e($hal->order); ?>" type="number" name="order" placeholder=".. no urut ..." class="span3 m-wrap">
                                                    </div>
                                                </div>
                                                <div class="controls span6">
                                                    <div class="control-group">
                                                        <ul class="thumbnails">
                                                            <li class="span2"> <a> <img src="<?php echo e(url('upload/'.$hal->id.'.jpg')); ?>" alt="" > </a>
                                                                <div class="actions">  <a class="lightbox_trigger" href="<?php echo e(url('upload/'.$hal->id.'.jpg')); ?>"><i class="icon-search"></i></a> </div>
                                                            </li>
                                                        </ul>
                                                        <label class="control-label">File upload input</label>
                                                        <div class="controls">
                                                            <input type="file" name="image" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <div class="controls">
                                                    <input value="<?php echo e($hal->judul); ?>" type="text" name="judul" id="required" placeholder=".. Judul ..." class="span12 m-wrap">
                                                </div>
                                            </div>
                                            <div class="controls">
                                                <textarea id="summernote" name="konten" class="textarea_editor span12" rows="6" placeholder=".. Konten halaman ..."><?php echo e($hal->konten); ?></textarea>
                                            </div>
                                            <div class="control-group">
                                                <div class="controls">
                                                    <input value="<?php echo e($hal->slug); ?>" type="text" name="slug" id="required" placeholder=".. Judul ..." class="span12 m-wrap">
                                                </div>
                                            </div>
                                            <div class="form-actions right">
                                                <button type="submit" class="btn btn-success btn-large">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end-main-container-part-->
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\penida\resources\views/backend/admin/nista/karang/edit.blade.php ENDPATH**/ ?>