<!--Header-part-->
<div id="header">
  <h1><a href="dashboard.html" style="color: #eee;">Administrator</a></h1>
</div>
<!--close-Header-part--> 

<!--top-Header-menu-->
<div id="user-nav" class="navbar navbar-inverse">
  <ul class="nav">
    <li class=""><a href="<?php echo e(route('home')); ?>" target="_blank"><i class="icon icon-home"></i> <span class="text">Home Page</span></a></li>
    <li><a title="" href="#" ><i class="icon icon-user"></i>  <span class="text">Welcome <?php echo e(Auth::user()->username); ?></span></a>
    </li>
    <li class=""><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="icon icon-off"></i> <span class="text">Logout</span></a></li>
  </ul>
  <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
      <?php echo csrf_field(); ?>
  </form>
</div>
<!--close-top-Header-menu-->

<!--start-top-serch-->
<div id="search">
  <input type="text" placeholder="Search here..."/>
  <button type="submit" class="tip-bottom" title="Search"><i class="icon-search icon-white"></i></button>
</div>
<!--close-top-serch--><?php /**PATH C:\laragon\www\penida\resources\views/layouts/backend/admin/header.blade.php ENDPATH**/ ?>