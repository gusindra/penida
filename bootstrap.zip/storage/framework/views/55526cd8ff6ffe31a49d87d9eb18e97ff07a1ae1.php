<!-- jQuery -->
<script src="<?php echo e(url('assets/travel/js/jquery.js')); ?>"></script>
<script src="<?php echo e(url('assets/travel/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/travel/js/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/travel/js/wow.js')); ?>"></script>
<script src="<?php echo e(url('assets/travel/js/jquery.mixitup.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/travel/js/jquery.fancybox.pack.js')); ?>"></script>
<script src="<?php echo e(url('assets/travel/js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/travel/js/jquery.counterup.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/travel/js/owl.carousel.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/travel/js/jquery.stellar.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/travel/js/bootstrap-datepicker.js')); ?>"></script>
<script type="text/javascript" src="http://maps.google.com/maps/api/js?js?sensor=false&key=AIzaSyCYI9QbpcEgmUSfnoBplXycjesknwlFW-w"></script>
<script src="<?php echo e(url('assets/travel/js/gmap3.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/travel/js/switcher.js')); ?>"></script>
<script src="<?php echo e(url('assets/travel/js/script.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('assets/travel/js/instafeed.min.js')); ?>"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-122565278-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-122565278-1');
</script>

<!-- WhatsHelp.io widget -->
<script type="text/javascript">
(function () {
var options = {
whatsapp: "	+6287766953397", // WhatsApp number
call_to_action: "Chat with us", // Call to action
position: "left", // Position may be 'right' or 'left'
};
var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
})();
</script>
<!-- /WhatsHelp.io widget -->
<?php /**PATH C:\laragon\www\penida\resources\views/layouts/travel/js.blade.php ENDPATH**/ ?>