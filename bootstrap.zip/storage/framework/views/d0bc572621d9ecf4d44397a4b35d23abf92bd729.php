<?php $__env->startSection('content'); ?>

    <!-- Page Title-->
    <section id="page-title" class="parallax" data-stellar-background-ratio="0.5" style="background-image: url(img/single-tour/bg.jpg);">
        <div class="title-info">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="page-title text-center">
                            <h1><?php echo e($konten->judul); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
        </div><!--end title-info-->
    </section>
    <!--end page-title-->

    <!-- Main Content -->
    <section class="main-content">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-md-8">
                    <div class="content-block">
                        <div class="single_post">
                            <div class="post_thumb">
                                <img src="<?php echo e($konten->gambar); ?>" alt="" />
                            </div><!--end post thumb-->

                            <div class="post_desc">
                                <?php echo $konten->konten; ?>


                            </div><!--end post desc-->

                        </div>

                    </div>
                </div>

                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="sidebar">
                        <div class="sidebar-item">
                            <h3>Booking Sekarang</h3>
                            <p><small>Silahkan isi form dibawah ini untuk melakukan pemesanan</small></p>
                            <?php if(session('message')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <?php echo e(session('message')); ?>

                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                            <?php endif; ?>
                            <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <form method="POST" action="<?php echo e(route('booking')); ?>">
                                <div class="form-group">

                                    <div class="input-group">

                                        <span class="input-group-addon"><i class="fa fa-user"></i></span>

                                        <input value="<?php echo e(old('name')); ?>" id="name" type="text" class="form-control" placeholder="Name" name="name">

                                    </div>

                                </div>



                                <div class="form-group">

                                    <div class="input-group">

                                        <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>

                                        <input value="<?php echo e(old('email')); ?>" id="email" type="text" class="form-control" placeholder="Email Address" name="email">

                                    </div>

                                </div>



                                <div class="form-group">

                                    <div class="input-group">

                                        <span class="input-group-addon"><i class="fa fa-phone"></i></span>

                                        <input value="<?php echo e(old('phone')); ?>" id="phone"  type="text" class="form-control" placeholder="Phone" name="phone">

                                    </div>

                                </div>



                                <div class="form-group">

                                    <div class="input-group">

                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>

                                        <input value="<?php echo e(old('date')); ?>" id="date" type="text" class="form-control date_pic" placeholder="" name="date" title="Tanggal tour">

                                    </div>

                                </div>

                                <div class="form-group">

                                    <div class="">

                                        <label>Paket Tour</label>

                                       <select name="tour" class="form-control">

                                           <?php $__currentLoopData = $tour; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <option <?php echo e($konten->id==$t->id?'selected':''); ?> value="<?php echo e($t->id); ?>"><?php echo e($t->judul); ?></option>

                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                       </select>

                                    </div>

                                </div>

                                <div class="form-group ">

                                    <div class="col-md-6">

                                        <div class="group ">

                                            <label>WNI</label>

                                            <input value="<?php echo e(old('wni', 0)); ?>" id="wni" type="number" class="form-control" placeholder="0" min="0" name="wni" title="Jumlah turis lokal">

                                        </div>

                                    </div>

                                    <div class="col-md-6">

                                        <div class="input ">

                                            <label>WNA</label>

                                            <input value="<?php echo e(old('wna', 0)); ?>" id="wna" type="number" class="form-control" placeholder="0" min="0" name="wna" title="Jumlah turis asing">

                                        </div>

                                    </div>

                                </div>

                                <br><br><hr>

                                 <div class="form-group">

                                    <div class="">

                                        <label>Keterangan</label>

                                        <textarea name="deskripsi" class="form-control"><?php echo e(old('deskripsi')); ?></textarea>

                                    </div>

                                </div>

                                <div class="text-center">

                                    <button type="submit" class="booking btn btn-primary">Book Sekarang</button>

                                </div>



                            </form>
                        </div><!--end sidebar-item-->


                    </div><!--end sidebar-->
                </div>

            </div>
        </div>
    </section>
    <!--end main-content-->

    <!-- Deals and Discounts -->
    <section id="deals-discounts" class="inverse">
        <div class="container">
            <div class="row">
                <div class="col-xs-12">
                    <div class="section-title text-center">
                        <h1>Related Tours</h1>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xs-12">
                    <div class="owl-carousel" id="deals-discounts-carousel">
                        <?php $__currentLoopData = $halaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tour-item">
                            <div class="thumb">
                                <img src="<?php echo e(url('upload/'.$h->id.'.jpg')); ?>" alt="" />
                            </div>

                            <div class="discount-info">
                                <h5><?php echo e($h->judul); ?></h5>
                                <a href="<?php echo e(route('page', $h->slug)); ?>">Selengkapnya <i class="fa fa-long-arrow-right"></i></a>
                            </div>

                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>

        </div>

    </section>
    <!--end deals-discounts-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.travel.main', ['sosmed' => $sosmed, 'app' => $app], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\penida\resources\views/travel/detail.blade.php ENDPATH**/ ?>