<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Add Pages')); ?>

        </h2>
     <?php $__env->endSlot(); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            <!--main-container-part-->
                <div id="content">
                    <!--breadcrumbs-->

                    <!--End-breadcrumbs-->
                    <div class="container-fluid">
                        <!--Action boxes-->
                        <div class="row-fluid">
                            <div class="widget-box">
                                <div class="widget-title"> <span class="icon"> <i class="icon-book"></i> </span>
                                    <h5>Halaman baru</h5>
                                </div>
                                <?php if(session('message')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('message')); ?>

                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                <?php endif; ?>
                                <?php echo $__env->make('partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="widget-content">
                                    <div class="control-group">

                                        <form action="<?php echo e(route('store.karang')); ?>" method="POST" files = "true">
                                            <?php echo csrf_field(); ?>
                                            <div class="control-group">
                                                <div class="controls span6">
                                                    <label>Tipe</label>
                                                    <select name="tipe">
                                                        <option value="page">Page</option>
                                                        <option value="tour">Package & Tour</option>
                                                        <option value="hotel">Hotel</option>
                                                    </select>
                                                </div>
                                                <div class="controls span6">
                                                    <div class="control-group">
                                                        <label class="control-label">File upload input</label>
                                                        <div class="controls">
                                                            <input type="file" name="image"/>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <br><br>
                                            <div class="control-group">
                                                <div class="controls">
                                                    <input type="text" name="judul" id="required" placeholder=".. Judul ..." class="judul span12 m-wrap">
                                                </div>
                                            </div>
                                            <div class="controls">
                                                <textarea id="summernote" name="konten" class="span12" rows="6" placeholder=".. Konten halaman ..."></textarea>
                                            </div>
                                            <div class="control-group">
                                                <div class="controls">
                                                    <input type="text" name="slug" id="required" placeholder="" class="slug span12 m-wrap">
                                                </div>
                                            </div>
                                            <div class="form-actions right">
                                                <button type="submit" class="btn btn-success btn-large">Buat</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <!--end-main-container-part-->
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php $__env->startSection('js'); ?>
<script src="<?php echo e(url('assets/js/backend/select2.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/backend/jquery.uniform.js')); ?>"></script>
<!-- include summernote css/js -->
<script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
<script src="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.js"></script>
<script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
    $(".judul").keyup(function(){
            var Text = $(this).val();
            Text = Text.toLowerCase();
            Text = Text.replace(/[^a-zA-Z0-9]+/g,'-');
            $(".slug").val(Text);
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/uniform.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/select2.css')); ?>" />
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.css" rel="stylesheet">
<link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php /**PATH C:\laragon\www\penida\resources\views/backend/admin/nista/karang/gae.blade.php ENDPATH**/ ?>