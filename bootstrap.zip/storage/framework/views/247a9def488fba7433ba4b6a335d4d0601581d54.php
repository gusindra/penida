<?php $__env->startSection('content'); ?>


    <!-- Banner Section -->
	<div id="banner" class="carousel slide carousel-fade" data-ride="carousel" data-pause="false">

		<!-- Wrapper for slides -->
		<div class="carousel-inner" role="listbox">
            <?php $__currentLoopData = $caption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="item <?php echo e($k==0?'active':''); ?>" style="background-image:url(img/banner/<?php echo e($k+1); ?>.jpg);">
				<div class="caption-info">
					<div class="container">
						<div class="row">
							<div class="col-sm-12 col-md-8 col-md-offset-2">
								<div class="caption-info-inner text-center">
									<h1 class="animated fadeInDown"><?php echo e($c->konten); ?></h1>
									<p class="animated fadeInUp"><?php echo e($c->deskripsi); ?></p>
									<!-- <a href="#packages" class="animated fadeInUp btn btn-primary page-scroll">Read More</a> -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		</div><!--end carousel-inner-->


		<!-- Controls -->
		<a class="control left" href="#banner" data-slide="prev"><i class="fa fa-long-arrow-left"></i></a>
		<a class="right control" href="#banner" data-slide="next"><i class="fa fa-long-arrow-right"></i></a>
	</div>
	<!--end Banner-->

	<!-- Services Section -->
	<section id="services">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="section-title text-center">
						<h1>Kenapa memilih Travelais</h1>
					</div>
				</div>
			</div>
			<div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s => $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-6 col-md-3">
                        <div class="service-list text-center wow fadeInUp">
                            <!--<img src="<?php echo e(url('img/service/mobil.png')); ?>" alt="Kami dampingi anda sejak mendarat di Bali" class="img-responsive">-->
                            <i class="fa fa-<?php echo e($s=='0'?'support':''); ?><?php echo e($s=='1'?'thumbs-o-up':''); ?><?php echo e($s=='2'?'camera':''); ?><?php echo e($s=='3'?'gift':''); ?>"></i>
                            <p><?php echo e($ser->konten); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>
		</div>
	</section>
	<!--end Services-->

	<!-- Packages Section -->
	<section id="packages" class="inverse">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="section-title text-center">
						<h1>Tour & Travel </h1>
					</div>
				</div>
			</div>

			<div class="row">
				<?php $__currentLoopData = $halaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="col-xs-6 col-sm-6 <?php echo e($key<3?'col-md-12':'col-md-4'); ?>">
					<div class="package-list wow fadeInUp">
						<a href="<?php echo e(route('page', $h->slug)); ?>">
							<div class="package-thumb">
								<img src="<?php echo e(url('upload/'.$h->id.'.jpg')); ?>" alt="" />
								<!-- <div class="duration">
									1 days<br/>1 nights
								</div> -->
							</div>
							<div class="package-info">
								<b><?php echo e($h->judul); ?></b>
							</div>
						</a>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
    <!-- end Packages -->

    <!-- Deals and Discounts -->
	<section id="deals-discounts" >
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="section-title text-center">
						<h1>Special Tour</h1>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-xs-12">
					<div class="owl-carousel" id="deals-discounts-carousel">

					<?php $__currentLoopData = $halaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="tour-item">
							<div class="thumb">
								<img src="<?php echo e(url('upload/'.$h->id.'.jpg')); ?>" alt="" />
							</div>

							<div class="discount-info">
								<b><?php echo e($h->judul); ?></b><br>
								<a href="<?php echo e(route('page',$h->slug)); ?>">Selengkapnya <i class="fa fa-long-arrow-right"></i></a>
							</div>

						</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</div><!--end deals-discounts-carousel-->
				</div>
			</div>

		</div>

	</section>
    <!--end deals-discounts-->

    <!-- Gallery Section -->
	<section id="gallery" class="inverse">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="section-title text-center">
						<h1>Gallery</h1>
					</div>
				</div>
			</div>

			<div class="row">
            	<div class="col-xs-12">
                	<ul id="filter-list">
                     	<li class="filter" data-filter="all">ALL</li>
                      	<li class="filter" data-filter="beach">beach</li>
                      	<li class="filter" data-filter="tour">tours</li>
                    </ul><!-- @end  #filter-list -->
                </div>
            </div>
		</div>
		<ul class="gallery-item">
			<li class="gallery beach">
				<div class="thumb">
					<img src="img/gallery/1.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Nusa Penida Beach</h2>
							<a href="img/gallery/1.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

			<li class="gallery beach tour">
				<div class="thumb">
					<img src="img/gallery/2.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Nusa Penida Beach</h2>
							<a href="img/gallery/2.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

			<li class="gallery beach">
				<div class="thumb">
					<img src="img/gallery/3.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Sunset Penida</h2>
							<a href="img/gallery/3.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

			<li class="gallery beach tour">
				<div class="thumb">
					<img src="img/gallery/4.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Nusa Penida Beach</h2>
							<a href="img/gallery/4.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

			<li class="gallery tours">
				<div class="thumb">
					<img src="img/gallery/5.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Fish Penida</h2>
							<a href="img/gallery/5.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

			<li class="gallery tour">
				<div class="thumb">
					<img src="img/gallery/6.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Tirtayatra Nusa Penida</h2>
							<a href="img/gallery/6.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

			<li class="gallery beach">
				<div class="thumb">
					<img src="img/gallery/7.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Kelingking Secret Point Beach</h2>
							<a href="img/gallery/7.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

			<li class="gallery tour">
				<div class="thumb">
					<img src="img/gallery/8.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Nusa Penida Treehouse</h2>
							<a href="img/gallery/8.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

			<li class="gallery tour">
				<div class="thumb">
					<img src="img/gallery/9.jpg" alt="" />
					<div class="gallery-overlay">
						<div class="gallery-overlay-inner">
							<h2>Turtle Penida</h2>
							<a href="img/gallery/9.jpg" class="fancybox"><i class="fa fa-camera"></i></a>
						</div>
					</div>
				</div><!--end post thumb-->
			</li>

		</ul>
		<div id="instafeed"></div>

	</section>
    <!-- end gallery-->

    <!-- Testimonials Section -->
	<section id="testimonials">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="section-title text-center">
						<h1>What our clients say?</h1>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="col-xs-12 col-sm-12 col-md-8 col-md-offset-2">
					<div class="owl-carousel" id="testimonial-carousel">
						<div class="testimonial-item text-center">
							<i class="fa fa-quote-left"></i>
							<div class="author-comments">
								<p>Beautiful island that you can enjoy together with friends or family. You can also do diving and snorkelling here because the sea is very clean and you can meet Mantas!.</p>
							</div>
							<div class="designation">
								Kyra Josep
							</div>
						</div>

						<div class="testimonial-item text-center">
							<i class="fa fa-quote-left"></i>
							<div class="author-comments">
								<p>Nusa Penida is stunning! There are so many beautiful things to explore and the people on the island are mostly very kind. I hope it will stay a paradise and I wish that the locals and tourist will clean up a little better in future.</p>
							</div>
							<div class="designation">
								Philip Sony
							</div>
						</div>

						<div class="testimonial-item text-center">
							<i class="fa fa-quote-left"></i>
							<div class="author-comments">
								<p>Amazing experience to visit here, u can feel the vibes around you, a beautiful magnificent view. It's like sit comfortably and see the natural beauty of world.</p>
							</div>
							<div class="designation">
								Singh Modesty
							</div>
						</div>

					</div>
				</div>
			</div>

		</div>
	</section>
	<!--end testimonials-->

	<!-- Contact Us Section-->
	<section id="contact-us" class="parallax" data-stellar-background-ratio="0.5" style="background-image: url(img/bg/contact-bg.jpg);">
		<div class="container">
			<div class="row">
				<div class="col-xs-12">
					<div class="section-title text-center">
						<h1>Hubungi Kami</h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12 col-sm-6 col-md-4">
					<div class="contact-left">
						<ul>
							<li>
								<div class="icon">
									<i class="fa fa-map-marker"></i>
								</div>
								<div class="contact-info">
                                    <?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($a->judul=='alamat'?$a->konten:''); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</li>

							<li>
								<div class="icon">
									<i class="fa fa-phone"></i>
								</div>
								<div class="contact-info">
                                    <?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($a->judul=='telp'?$a->konten:''); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</li>

							<li>
								<div class="icon">
									<i class="fa fa-envelope"></i>
								</div>
								<div class="contact-info">
                                    <?php $__currentLoopData = $app; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><a href="mailto:<?php echo e($a->judul=='email'?$a->konten:''); ?>"><?php echo e($a->judul=='email'?$a->konten:''); ?></a></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</div>
							</li>

							<!-- <li>
								<div class="icon">
									<i class="fa fa-clock-o"></i>
								</div>
								<div class="contact-info">
									<p>Monday-Friday: 9am - 5pm <br/> Saturday: 10am - 2pm<br/> Sunday - Closed </p>
								</div>
							</li> -->

						</ul>
					</div>
				</div>

				<div class="col-xs-12 col-sm-6 col-md-8">
					<div class="contact-right">
                        <form method="POST" action="<?php echo e(route('contact')); ?>">
							<div class="row">
								<div class="col-sm-12 col-md-12">
									<div class="form-group">
										<input type="text" name="name" class="form-control" placeholder='Name'>
									</div>
								</div>
							</div>
							<div class="form-group">
								<input type="text" name="email" class="form-control" placeholder='Email Address'>
							</div>
							<div class="form-group">
								<textarea class="form-control" name="konten" rows="6" cols="20" placeholder="Write Something"></textarea>
							</div>
							<button type="submit" class="btn btn-primary" name="submit" value="">Submit</button>

                        </form>
					</div>
				</div>

				<div class="clearfix"></div>
				<br>
				<hr>
				<div class="row">
    				<div class="col-xs-12">
    					<div class="">
    						<h5>Liburan di Nusa Penida ~ Travelais Tour dan Travel di Pulau Nusa Penida</h5>
                            <article>
                                <p style="font-size: 10px;">Layanan dari Travelais telah terpercaya memberikan pengalaman terbaik bagi klien-klien kami saat berliburan di Pulau Nusa Penida. Kenyamanan yang kami tawarkan untuk setiap lokasi wisata dengan menyediakan peralatan, transportasi dan akomodasi penginapan yang terbaik.</p>
                            </article>
                            <h5>Holidays in Nusa Penida ~ Travelais Service for Tour and Travel on Nusa Penida Island</h5>
                            <article>
                                <p style="font-size: 10px;">The services of Travelais have been trusted to provide the best experience for our clients while on vacation on Nusa Penida Island. Comfort that we offer for each tourist location by providing the best equipment, transportation and lodging accommodations.</p>
                            </article>
    					</div>
    				</div>
    			</div>
			</div>

		</div>
	</section>
	<!--end contact-us-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.travel.main', ['sosmed' => $sosmed, 'app' => $app], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\penida\resources\views/travel/home.blade.php ENDPATH**/ ?>