<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Pages')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <!--main-container-part-->
                    <div id="content">
                        <!--breadcrumbs-->
                        <div class="content-header flex">
                            <h1>Halaman</h1>
                            <a class="inline-flex items-center ml-2 px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition" href="<?php echo e(route('add.karang')); ?>" >Tambah</a>
                        </div>
                        <!--End-breadcrumbs-->

                        <!--Action boxes-->
                        <div class="container-fluid">
                            <div class="row-fluid">
                                <div class="span12">
                                    <!--Chart-box-->
                                    <div class="widget-box">
                                        <div class="widget-content nopadding">
                                            <table class="table-fixed">
                                                <thead>
                                                    <tr>
                                                        <th class="w-1/2">Image</th>
                                                        <th class="w-1/2">Content</th>
                                                        <th class="w-1/4">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = @$hal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $halaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><img width="100" height="80" src="<?php echo e(url('upload/'.$halaman->id.'.jpg')); ?>" alt="" ></td>
                                                            <td class="w-1/2"><?php echo e($halaman->order?$halaman->order.'.':''); ?> <?php echo e($halaman->judul); ?></td>
                                                            <td class="flex">
                                                                <a class="inline-flex items-center ml-2 px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition" target="_blank" href="<?php echo e(route('page', $halaman->slug)); ?>" >Lihat</a>
                                                                <a class="inline-flex items-center ml-2 px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition" href="<?php echo e(route('edit.karang', $halaman->id)); ?>" >Ubah</a>
                                                                <form method="POST" action="<?php echo e(route('hapus.karang', $halaman->id)); ?>" class="delete">
                                                                    <?php echo csrf_field(); ?>
                                                                    <input type="hidden" name="_method" value="DELETE">
                                                                    <button class="inline-flex ml-2 items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition" type="submit">Hapus</button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!--End-Chart-box-->
                                </div>
                            </div>

                        </div>
                    </div>
                <!--end-main-container-part-->
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>


<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(url('assets/js/backend/jquery.dataTables.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/backend/select2.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php /**PATH C:\laragon\www\penida\resources\views/backend/admin/nista/karang/karang.blade.php ENDPATH**/ ?>