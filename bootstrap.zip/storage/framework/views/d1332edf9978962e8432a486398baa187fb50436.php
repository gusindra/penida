<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/bootstrap-responsive.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/fullcalendar.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/matrix-style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/matrix-media.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/font-awesome.css')); ?>"  />
<link rel="stylesheet" href="<?php echo e(url('assets/css/backend/jquery.gritter.css')); ?>" />
<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'><?php /**PATH C:\laragon\www\penida\resources\views/layouts/backend/admin/css.blade.php ENDPATH**/ ?>