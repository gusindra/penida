<!--sidebar-menu-->
<div id="sidebar"><a href="#" class="visible-phone"><i class="icon icon-home"></i> Dashboard</a>
  <ul>
    <li class="<?php echo e(Request::route()->getName() =='mandala' ? 'active' : ''); ?>"><a href="<?php echo e(route('mandala')); ?>"><i class="icon icon-th"></i> <span>Beranda</span></a> </li>
    <li class="submenu <?php echo e(Request::route()->getName() =='karang' ? 'active' : ''); ?>"> <a href="#"><i class="icon icon-book"></i> <span>Halaman</span> </a>
      <ul style="display: none;">
        <li><a href="<?php echo e(route('gae.karang')); ?>">Tambah Halaman</a></li>
        <li><a href="<?php echo e(route('karang')); ?>">Lihat Halaman</a></li>
      </ul>
    </li>
    <li class="<?php echo e(Request::route()->getName() =='bale' ? 'active' : ''); ?>"> <a href="<?php echo e(route('bale')); ?>"><i class="icon icon-cog"></i> <span>Pengaturan</span></a></li>
    <li class="<?php echo e(Request::route()->getName() =='meli' ? 'active' : ''); ?>"> <a href="<?php echo e(route('meli')); ?>"><i class="icon icon-envelope"></i> <span>Orders</span> <span class="label label-important"><?php echo e($num_order); ?></span></a></li>
  </ul>
  
</div>
<!--sidebar-menu--><?php /**PATH C:\laragon\www\penida\resources\views/layouts/backend/admin/sidebar.blade.php ENDPATH**/ ?>