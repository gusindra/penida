<?php

namespace App\Http\Controllers\Back;

use App\Models\User;
use App\Models\Pengaturan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\UserRequest;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;


class BaleController extends BackadminController
{

    public function addOrupdate(Request $request)
    {
        foreach ($request->all() as $key => $value) {
            if ($key!='_method' && $key!='_token' && !empty($value)) {
                DB::transaction(function () use ($key, $value) {
                    DB::table('pengaturan')->where('id', $key)->update(['konten' => $value]);
                });
            }
        }

        return redirect()->back()->with('message','Sukses mengubah pengaturan');
    }

    public function update(Request $request)
    {
        foreach ($request->all() as $key => $value) {
            if ($key!='_method' && $key!='_token' && !empty($value)) {
                DB::transaction(function () use ($key, $value) {
                    DB::table('pengaturan')->where('id', $key)->update(['konten' => $value]);
                });
            }
        }

        return redirect()->back()->with('message','Sukses mengubah pengaturan');
    }

    public function updatecaption(Request $request)
    {
        // return $request->all();
        foreach ($request->get('judul') as $key => $value) {
            if ($key!='_method' && $key!='_token' && !empty($value)) {
                DB::transaction(function () use ($key, $value) {
                    DB::table('pengaturan')->where('id', $key)->update(['konten' => $value]);
                });
            }
        }
        foreach ($request->get('deskripsi') as $key => $value) {
            if ($key!='_method' && $key!='_token' && !empty($value)) {
                DB::transaction(function () use ($key, $value) {
                    DB::table('pengaturan')->where('id', $key)->update(['deskripsi' => $value]);
                });
            }
        }

        return redirect()->back()->with('message','Sukses mengubah pengaturan');
    }
}
