<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Edit Pages') }}
        </h2>
    </x-slot>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <!--main-container-part-->
                <div id="content">

                    <!--End-breadcrumbs-->
                    <div class="container-fluid">
                        <!--Action boxes-->
                        <div class="row-fluid">
                            <div class="widget-box">
                                <div class="widget-title"> <span class="icon"> <i class="icon-book"></i> </span>
                                    <h5>Halaman edit</h5>
                                </div>
                                @if (session('message'))
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        {{ session('message') }}
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                @endif
                                @include('partials.messages')
                                <div class="widget-content">
                                    <div class="control-group">
                                        <form method="POST" enctype="multipart/form-data" action="{{route('update.karang', $hal->id)}}"  >
                                            @csrf
                                            <input type="hidden" name="_method" value="PUT">
                                            <div class="control-group">
                                                <div class="controls span6">
                                                    <div class="controls">
                                                        <label>Tipe</label>
                                                        <select name="tipe">
                                                            <option {{$hal->tipe=='page'?'selected':''}} value="page">Page</option>
                                                            <option {{$hal->tipe=='tour'?'selected':''}} value="tour">Package & Tour</option>
                                                            <option {{$hal->tipe=='hotel'?'selected':''}} value="hotel">Hotel</option>
                                                        </select>
                                                    </div>
                                                    <br>
                                                    <div class="controls">
                                                        <label>No Urut</label>
                                                        <input value="{{$hal->order}}" type="number" name="order" placeholder=".. no urut ..." class="span3 m-wrap">
                                                    </div>
                                                </div>
                                                <div class="controls span6">
                                                    <div class="control-group">
                                                        <ul class="thumbnails">
                                                            <li class="span2"> <a> <img src="{{url('upload/'.$hal->id.'.jpg')}}" alt="" > </a>
                                                                <div class="actions">  <a class="lightbox_trigger" href="{{url('upload/'.$hal->id.'.jpg')}}"><i class="icon-search"></i></a> </div>
                                                            </li>
                                                        </ul>
                                                        <label class="control-label">File upload input</label>
                                                        <div class="controls">
                                                            <input type="file" name="image" />
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="control-group">
                                                <div class="controls">
                                                    <input value="{{$hal->judul}}" type="text" name="judul" id="required" placeholder=".. Judul ..." class="span12 m-wrap">
                                                </div>
                                            </div>
                                            <div class="controls">
                                                <textarea id="summernote" name="konten" class="textarea_editor span12" rows="6" placeholder=".. Konten halaman ...">{{$hal->konten}}</textarea>
                                            </div>
                                            <div class="control-group">
                                                <div class="controls">
                                                    <input value="{{$hal->slug}}" type="text" name="slug" id="required" placeholder=".. Judul ..." class="span12 m-wrap">
                                                </div>
                                            </div>
                                            <div class="form-actions right">
                                                <button type="submit" class="btn btn-success btn-large">Simpan</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--end-main-container-part-->
            </div>
        </div>
    </div>
</x-app-layout>
