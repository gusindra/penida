<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Pages') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
                <!--main-container-part-->
                    <div id="content">
                        <!--breadcrumbs-->
                        <div class="content-header flex">
                            <h1>Halaman</h1>
                            <a class="inline-flex items-center ml-2 px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition" href="{{ route('add.karang') }}" >Tambah</a>
                        </div>
                        <!--End-breadcrumbs-->

                        <!--Action boxes-->
                        <div class="container-fluid">
                            <div class="row-fluid">
                                <div class="span12">
                                    <!--Chart-box-->
                                    <div class="widget-box">
                                        <div class="widget-content nopadding">
                                            <table class="table-fixed">
                                                <thead>
                                                    <tr>
                                                        <th class="w-1/2">Image</th>
                                                        <th class="w-1/2">Content</th>
                                                        <th class="w-1/4">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach(@$hal as $k => $halaman)
                                                        <tr>
                                                            <td><img width="100" height="80" src="{{url('upload/'.$halaman->id.'.jpg')}}" alt="" ></td>
                                                            <td class="w-1/2">{{$halaman->order?$halaman->order.'.':''}} {{$halaman->judul}}</td>
                                                            <td class="flex">
                                                                <a class="inline-flex items-center ml-2 px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition" target="_blank" href="{{ route('page', $halaman->slug) }}" >Lihat</a>
                                                                <a class="inline-flex items-center ml-2 px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition" href="{{ route('edit.karang', $halaman->id) }}" >Ubah</a>
                                                                <form method="POST" action="{{ route('hapus.karang', $halaman->id) }}" class="delete">
                                                                    @csrf
                                                                    <input type="hidden" name="_method" value="DELETE">
                                                                    <button class="inline-flex ml-2 items-center px-4 py-2 bg-gray-800 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 active:bg-gray-900 focus:outline-none focus:border-gray-900 focus:ring focus:ring-gray-300 disabled:opacity-25 transition" type="submit">Hapus</button>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <!--End-Chart-box-->
                                </div>
                            </div>

                        </div>
                    </div>
                <!--end-main-container-part-->
            </div>
        </div>
    </div>
</x-app-layout>


@section('js')
    <script src="{{ url('assets/js/backend/jquery.dataTables.min.js') }}"></script>
@endsection

@section('css')
    <link rel="stylesheet" href="{{ url('assets/css/backend/select2.css') }}" />
@endsection
